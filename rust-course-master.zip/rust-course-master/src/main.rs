mod homeworks;
mod lectures;
mod practice;

fn main() {
    println!("Hello from \u{211D}u\x73\x74😀!");
}
