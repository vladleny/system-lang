mod a0types;
mod a1minmaxvalues;
mod a2converting;
mod a3negatives;
mod a4overflow;
mod a5floats;
mod a6literals;
mod a7binary_basics;
