fn min(xs: &[i32]) -> i32 {
    todo!()
}

fn index_of(x: i32, xs: &[i32]) -> usize {
    todo!()
}

fn read_file(name: String) -> String {
    todo!()
}

fn whatever(color: &str) {
    todo!()
}

fn test() {
    whatever("red");
    whatever("Red");
    whatever("RED");
    whatever("yellow");
    whatever("YELLOW");
    whatever("Green");
    whatever("Greeen");
}
