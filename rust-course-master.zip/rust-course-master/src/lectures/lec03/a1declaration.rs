#[test]
fn declaration() {
    let xs: [i32; 5] = [10, 20, 30, 40, 50];

    let xs = [10, 20, 30, 40, 50];

    let xs = [true, false];

    // let xs = []; // will not compile
}
