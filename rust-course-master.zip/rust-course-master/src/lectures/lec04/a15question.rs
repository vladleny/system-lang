#[test]
fn question() {
    let s = "я😀";
    assert_eq!(s.len(), 6);
}
