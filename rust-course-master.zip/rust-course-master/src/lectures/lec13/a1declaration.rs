fn test131() {
    print!("hello");
}
