### manipulation

- cycle
- enumerate
- next
- advance_by
- map
- map_while
- filter
- filter_map
- flat_map
- zip
- unzip
- take
- skip
- take_while
- skip_while
- scan

### termination

- for_each
- collect
- count
- sum
- all
- any
- reduce
- fold