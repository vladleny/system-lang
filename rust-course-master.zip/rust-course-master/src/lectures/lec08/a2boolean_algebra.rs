fn not(x: bool) -> bool {
    !x
}

fn and(x: bool, y: bool) -> bool {
    x && y
}

fn or(x: bool, y: bool) -> bool {
    x || y
}
