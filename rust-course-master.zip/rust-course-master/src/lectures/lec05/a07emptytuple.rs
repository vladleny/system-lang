fn test() {
    // empty tuple is unit
    let x = ();
}
