mod char_indexes;
