mod brackets_is_valid;
