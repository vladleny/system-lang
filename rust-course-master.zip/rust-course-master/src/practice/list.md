### practical lessons

1. github
2. project structure, compile, run
3. 5317^1000000000
4. envelope - console
5. apples_and_oranges
6. chess_board - console
7. rhombus - console
8. brackets_is_valid_simple - string/array
9. brackets_max_level - string/array
10. shoes_groups - string/array
11. counting_valleys - string/array
12. parking_dilemma - array/array
13. brackets_is_valid_full - string/array
14. char_indexes - data manipulation
15. pack-unpack - data manipulation
