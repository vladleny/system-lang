## Recordings List 2024/2025 - 2nd semester

### 17.02.2025

044-1
https://us02web.zoom.us/recording/detail?meeting_id=UH8BiYdkRuukorZaYiJMVg%3D%3D
044-2
https://us02web.zoom.us/recording/detail?meeting_id=1CIUvQQyQ5aLqj0SsZf2kg%3D%3D

### 21.02.2025

034-1
https://us02web.zoom.us/recording/detail?meeting_id=HimaOeBsR6CiHUxd4xl%2FSA%3D%3D
034-2
https://us02web.zoom.us/recording/detail?meeting_id=6V42Iu8VS4629%2FJF73wD6g%3D%3D

044-3
https://us02web.zoom.us/recording/detail?meeting_id=yTEeQI8XT8qVrmUIGEi38A%3D%3D
044-4
https://us02web.zoom.us/recording/detail?meeting_id=Z%2FDd46Q1QJyrE%2FoEu0eWxw%3D%3D

### 24.02.2025

044-5
044-6

### 28.02.2025

034-3
034-4
044-7
044-8


