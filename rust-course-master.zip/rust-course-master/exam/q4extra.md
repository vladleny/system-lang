### Exam. 4. extra question

- fizzbuzz
- envelope
- group + filter and count
- option add
- print matrix in one iteration
