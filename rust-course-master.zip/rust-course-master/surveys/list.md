## Control Surveys

### Survey 1. Into

https://docs.google.com/forms/d/1vAIPl4Ccj_B4IlIKPfN5LBo1zSsIg0lKIdzoH-yhtZ8/edit

### Survey 2. Data Types

https://docs.google.com/forms/d/1JFMUMThx915QK3kucyGUvD1KGtFgUuymwVRF-XwCqIE/edit

### Survey 3. Arrays

https://docs.google.com/forms/d/1VgWlFcd_n7x9ejzTHp5_KWiAq1F773GO1kYJvQLCjG0/edit

### Survey 4. String

https://docs.google.com/forms/d/1JL4v0WrHu6jvJJ_hzckpNZeeMqRbklbI4tYFscK45Fs/edit

### Survey 5. Products

https://docs.google.com/forms/d/1OMCwDqNvCrj_Sd1_q_fWB4pZyNH-ZQ8xPe7mZji5FeI/edit

### Survey 6. Coproducts

https://docs.google.com/forms/d/1Su_cs2kEJ1JYxNlWZEcuZHkBr172O9cmR9OC_ClesqY/edit

### Survey 7. Pattern Matching

https://docs.google.com/forms/d/1KBYCljOohF0Y-zn6lfc0HNofwMPi5iy4GV-m6QLlMIM/edit

### Survey 8. Control Flow

https://docs.google.com/forms/d/1OvTLswRXuKxrRvDdtVGSKt0jwKHxjqv0RDSQBhMTnyc/edit

### Survey 9. Functions, Closures

https://docs.google.com/forms/d/1CLX41D5s30Q14-J_R8gY92KmaOIkhz6THM2qAeOf73U/edit

### Survey 10. Impl, Traits

https://docs.google.com/forms/d/1T5CXTxDu_eFNm9VKQ7tHqDfb_qd28bZW57VlAlWjFDc/edit

### Survey 11. Collections

[//]: # (TODO)
https://docs.google.com/forms/d/10uyUfPH6qMVqYblrWeQ5dxQEajT9fuMZFg3Bn3ZcVZo/edit

### Survey 12. Iterators

https://docs.google.com/forms/d/13bt6LGJhixrPL-jMzz-LxP0W9WfSHfpQLzEKXJ5y9KA/edit

### Survey 13. Memory

[//]: # (TODO)
https://docs.google.com/forms/d/1ds-lAJYGIQvrzxmckEqGrkmzySx08GdHCg-Uc7chvlw/edit

### Survey 14. Input/Output

[//]: # (TODO)
https://docs.google.com/forms/d/1Og9kdh0AdgmqSTPW5ybKiFTz5P_of1Aubs-aWPiOe08/edit

### Survey 15. Testing. Ecosystem

[//]: # (TODO)
https://docs.google.com/forms/d/1vX7izIz4YgPZLp3d43nBvDEcR0p55kYtPs5kOl3l31M/edit
