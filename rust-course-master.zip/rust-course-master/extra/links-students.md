### Інсталяція компілятора мови програмування Rust

https://www.rust-lang.org/tools/install

### Інсталяція Integrated Develpoment Environment Rust

https://www.jetbrains.com/rust/download

### Офіційна документація Rust (всього 21 глава, Читаємо тільки 1-6,8-13,17-18)

https://doc.rust-lang.org/stable/book/

### Дуже класне відео для початківців

https://www.youtube.com/watch?v=BpPEoZW5IiY

### Система контролю версій та роботи в команді GIT

https://git-scm.com/downloads
