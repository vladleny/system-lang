## System Programming in Rust. Syllabus. II semester

### Lecture 1. Functional programming

- successors
- scan
- fold
- flat_map

### Lecture 2. Recursion
- ...

### Lecture 3. Concurrency. Fundamentals

- concurrency fundamentals
- spawn
- sleep

### Lecture 4. Concurrency. Primitives

- thread
- mutex
- messaging

### Lecture 5. Concurrency. Tokio

- .
- .

### Lecture 6. Memory. Box, Rc, Arc

- .
- .

### Lecture 7. I/O USB

- .
- .

### Lecture 8. I/O Process

- .
- .

### Lecture 9. I/O System calls

- .
- .

### Lecture 10. UseCases. DateTime

- .
- .

### Lecture 11. UseCases. Serialization, Json

- .
- .

### Lecture 12. UseCases. Random

- .
- .

### Lecture 13. UseCases. Console App

- .
- .

### Lecture 14. UseCases. WebServer

- .
- .

### Lecture 15. UseCases. Database SQL

- .
- .

### Lecture 16. UseCases. Designing Libraries, Crates

- .
- .

### Coursework
